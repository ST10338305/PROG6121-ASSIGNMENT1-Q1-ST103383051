/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentapplication;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class Student {
    //private variables
    private int studentID;
    private String studentName;
    private int studentAge;
    private String fieldOfStudy;
    private String studentEmail;

    // Constructor of student class to uses privates
    public Student(int id, String name, int age, String fieldOfStudy, String email) {
        this.studentID = id;
        this.studentName = name;
        this.studentAge = age;
        this.fieldOfStudy = fieldOfStudy;
        this.studentEmail = email;
    }
    
    // Getters and setters
    public int getStudentID() {
        return studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getFieldOfStudy() {
        return fieldOfStudy;
    }

    public String getStudentEmail() {
        return studentEmail;
    }
    
    // Collecting student details from user input and adding to the students Array list
    public static void createStudent(Scanner scanner, ArrayList<Student> students, int studentIDCounter) {//create student method with the array passed through
        int id = -1;
        boolean validInput = false;

        do {
            try {
                System.out.println("Enter student ID (Must not contain letters or special characters):");//restriction
                id = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException e) {//when whats entered does not meet what was asked for
                System.out.println("Invalid input. Please enter an integer for the student ID.");
                scanner.nextLine(); // Consume the invalid input
            }
        } while (!validInput);//while the validimput is true
        
        scanner.nextLine(); // Consume the newline character

        System.out.println("Enter student name:");
        String name = scanner.nextLine();

       int age = -1;
    validInput = false;

    do {
        try {
            System.out.println("Enter student age that is greater than 16 and not a String:");
            age = scanner.nextInt();

            if (age >= 16) {
                validInput = true;
            } else {
                System.out.println("Invalid age. Please enter an age greater than or equal to 16.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter an integer for the student age.");
            scanner.nextLine(); // Consume the invalid input
        }
    } while (!validInput);

    scanner.nextLine();// Consume the newline character

        System.out.println("Enter student field of study:");
        String fieldOfStudy = scanner.nextLine();//getting the field of study

        String email;
        do {
            System.out.println("Enter student email (must contain '@'):");//restriction
            email = scanner.nextLine();
        } while (!email.contains("@"));//will reprompt if it does not contain the special character

        Student student = new Student(id, name, age, fieldOfStudy, email);
        students.add(student);

        System.out.println("Student details have been successfully saved.");//message to show the student was saved
    }
    // Search for a student by ID and display their details
    //alternativly use their names
    public static void searchStudent(Scanner scanner, ArrayList<Student> students) {//search method with the student array passed
        System.out.println("Enter student ID or Student name to search:");
       
         String searchInput = scanner.next();

        boolean found = false;
    for (Student student : students) {
        if (isNumeric(searchInput)) {//if ints are entered to search
            int searchID = Integer.parseInt(searchInput);
            if (student.getStudentID() == searchID) {//if the enetered id mathches what in memory
                student.displayStudentDetails();//prints the details
                found = true;
                break;
            }
        } else {
            if (student.getStudentName().equalsIgnoreCase(searchInput)) {//ignores if what was entered was captialized
                student.displayStudentDetails();
                found = true;
                break;
            }
        }
    }
        if (!found) {
            System.out.println("Student cannot be located.");
        }
    }
    
    // Helper method to check if a string is numeric
private static boolean isNumeric(String str) {
    try {
        Integer.parseInt(str);
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}
    
    // Delete a student by ID
    public static void deleteStudent(Scanner scanner, ArrayList<Student> students) {//deleted method with the students array passed
        System.out.println("Enter student ID to delete:");
        int deleteID = scanner.nextInt();

        Student studentToRemove = null;
        for (Student student : students) {
            if (student.getStudentID() == deleteID) {
                studentToRemove = student;//tranfering whats in the array
                break;
            }
        }

         if (studentToRemove != null) {
            System.out.println("Are you sure you want to delete this student? (yes/no)");//confirmstion of deletion
            scanner.nextLine(); // Consume the newline character
            String confirmation = scanner.nextLine();

            if (confirmation.equalsIgnoreCase("yes")) {
                students.remove(studentToRemove);//removed
                System.out.println("Student has been deleted.");
            } else {
                System.out.println("Student deletion canceled.");
            }
        } else {
            System.out.println("Student cannot be located.");
        }
    }
    
    // Display the student report
    public static void displayStudentReport(ArrayList<Student> students) {
        System.out.println("Student Report:");//student report
        System.out.println("****************************************************");
        for (int i = 0; i < students.size(); i++) {
        Student student = students.get(i);
        System.out.println("Student " + (i + 1) + ":");
        student.displayStudentDetails();
      
         System.out.println("****************************************************");
    }
        }
    

   
   // Display student details
    public void displayStudentDetails() {
        System.out.println("************************************");
        System.out.println("Student ID: " + studentID);
        System.out.println("Student Name: " + studentName);
        System.out.println("Student Age: " + studentAge);
        System.out.println("Field of Study: " + fieldOfStudy);
        System.out.println("Student Email: " + studentEmail);
        System.out.println("************************************");
    }
    
    public static void exit(){
        System.out.println("You have quit :)");
    }
}


