/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentapplication;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author David
 */
public class StudentTest {
    
    public StudentTest() {
    }

    @Test
    public void testGetStudentID() {
    }

    @Test
    public void testGetStudentName() {
    }

    @Test
    public void testGetStudentAge() {
    }

    @Test
    public void testGetFieldOfStudy() {
    }

    @Test
    public void testGetStudentEmail() {
    }

    @Test
    public void testCreateStudent() {
        
        // Create a test ArrayList for students
        ArrayList<Student> students = new ArrayList<>();
        int studentIDCounter = 1;

        // Create a Scanner with a custom input for testing
        String input = "123\nJohn\n20\nMath\njohn@example.com\n";
        Scanner scanner = new Scanner(new ByteArrayInputStream(input.getBytes()));

        // Call the createStudent method
        Student.createStudent(scanner, students, studentIDCounter);

        // Verify that the student was added to the list
        assertEquals(1, students.size());
        
         // Verify the details of the student
        Student student = students.get(0);
        assertEquals(123, student.getStudentID());
        assertEquals("John", student.getStudentName());
        assertEquals(20, student.getStudentAge());
        assertEquals("Math", student.getFieldOfStudy());
        assertEquals("john@example.com", student.getStudentEmail());

    }

    @Test
    public void testSearchStudent() {
        
        
    }
    
    @Test
    public void testSearchStudentByID() {
        // Create a test ArrayList for students
        ArrayList<Student> students = new ArrayList<>();
        Student student0 = new Student(1, "John", 20, "Math", "john@example.com");
        Student student1 = new Student(2, "Alice", 22, "Science", "alice@example.com");
        students.add(student0);
        students.add(student1);

        // Create a Scanner with a custom input for testing
        String input = "1";
        Scanner scanner = new Scanner(input);

        // Call the searchStudent method
        Student.searchStudent(scanner, students);

        // Verify that the student details were displayed
        assertEquals(2, students.size());
    }
    
    @Test
    public void testSearchStudentNotFound() {
        // Create a test ArrayList for students
        ArrayList<Student> students = new ArrayList<>();
        Student student1 = new Student(1, "John", 20, "Math", "john@example.com");
        Student student2 = new Student(2, "Alice", 22, "Science", "alice@example.com");
        students.add(student1);
        students.add(student2);

        // Create a Scanner with a custom input for testing
        String input = "3\n"; // Searching for a non-existing student ID
        Scanner scanner = new Scanner(input);

        // Call the searchStudent method
        Student.searchStudent(scanner, students);

        // Verify that an appropriate message was displayed
        assertEquals(2, students.size()); // No student should be removed
    }

    @Test
    public void testDeleteStudent() {
    } 
         @Test
    public void testDeleteStudentConfirmed() {
        // Create a test ArrayList for students
        ArrayList<Student> students = new ArrayList<>();
        Student student1 = new Student(1, "John", 20, "Math", "john@example.com");
        Student student2 = new Student(2, "Alice", 22, "Science", "alice@example.com");
        students.add(student1);
        students.add(student2);

        // Create a Scanner with a custom input for testing
        String input = "2\nyes\n";
        Scanner scanner = new Scanner(input);

        // Call the deleteStudent method
        Student.deleteStudent(scanner, students);

        // Verify that the student was deleted
        assertEquals(1, students.size());
        assertEquals(student1, students.get(0));
    }
    
    
    @Test
    public void testDeleteStudentNotFound() {
        // Create a test ArrayList for students
        ArrayList<Student> students = new ArrayList<>();
        Student student1 = new Student(1, "John", 20, "Math", "john@example.com");
        Student student2 = new Student(2, "Alice", 22, "Science", "alice@example.com");
        students.add(student1);
        students.add(student2);

        // Create a Scanner with a custom input for testing
        String input = "3\nno\n"; // Deleting a non-existing student
        Scanner scanner = new Scanner(input);

        // Call the deleteStudent method
        Student.deleteStudent(scanner, students);

        // Verify that no student was deleted
        assertEquals(2, students.size());
    }



    @Test
    public void testDisplayStudentReport() {
    }

    @Test
    public void testDisplayStudentDetails() {
    }
    
}
