/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class StudentApplication {

    /**
     * @param args the command line arguments
     */
    
     private static ArrayList<Student> students = new ArrayList<>();
    private static int studentIDCounter = 1;
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);//instance of class
        int choice;

        do {
            displayMenu();
            choice = scanner.nextInt();

            switch (choice) { //switch casefor the different options we have
                case 1:
                    Student.createStudent(scanner, students, studentIDCounter);
                    studentIDCounter++;//after a student number increments
                    break;
                case 2:
                    Student.searchStudent(scanner, students); //option2 is search student
                    break;
                case 3:
                    Student.deleteStudent(scanner, students); //option 3 is delete student
                    break;
                case 4:
                    Student.displayStudentReport(students); //option 4 is display the students report
                    break;
              
                    case 5:
                    System.out.println("Exiting the program.");
                    Student.exit();
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        } while (choice != 5);//while the choice in not equal to 5(exit),the menu is displayed and we have access to the program
    }
    private static void displayMenu() {//main menu of the application
        System.out.println("****************************************************");
        System.out.println("Please select from the following menu items:");
        System.out.println("1. Create student");
        System.out.println("2. Search for a student");
        System.out.println("3. Delete student");
        System.out.println("4. Display student report");
        System.out.println("5. Exit program");
         System.out.println("****************************************************");
        
    }
    
}

//REFERNCES
//Smith, J.A. and Farrell, J. (2009) Java programs to accompany programming logic and Design. Boston, MA: Course Technology.
//https://www.geeksforgeeks.org/how-do-dynamic-arrays-work/
//https://java2blog.com/java-isnumeric/
//https://www.javatpoint.com/java-do-while-loop
//https://www.programiz.com/java-programming/examples/pass-arraylist-as-function-argument
//https://www.tutorialspoint.com/java/util/scanner_close.htm#:~:text=close()%20method%20closes%20this,method%20will%20have%20no%20effect.
//https://www.programiz.com/java-programming/bytearrayinputstream
